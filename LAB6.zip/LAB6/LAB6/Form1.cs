﻿//GRADING ID: X7694
//CIS 199-02
//Lab 6
//March 25, 2018
//This application will provide a grade based on words typed per minute
//This application will use arrays and range matching

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int wordsPerMinute; //User input for WPM
            int index; //Index for Array
            string grade = ""; //Student Grade as empty string, range matching will pull value if conditions are met


            bool found = false; //Boolean Value, True? False?

            int[] limits = { 0, 15, 30, 50, 75 }; //WPM Limits
            string[] grades = { "F", "D", "C", "B", "A" }; //Grades based on WPM 

            if (int.TryParse(wpm.Text, out wordsPerMinute) && wordsPerMinute >= 0) // If/Else statement for array and range matching
            {
                index = limits.Length - 1; //Length of array, starting from end and ending at beginning
                while (index >= 0 && !found) //While Loop, greater than or equal to 0 AND found
                {
                    if (wordsPerMinute > limits[index]) //If WPM is greater than limit, then found(true)
                        found = true;
                    else
                        --index; //End to beginning of array if conditions were not met



                }

                if (found) //If found, Display output
                    grade = grades[index];
                        output.Text = grade;
            }
            else
            MessageBox.Show("Please enter valid Words Per Minute"); //Message Box Error if user did not enter a valid WPM score


        }
    }
}
