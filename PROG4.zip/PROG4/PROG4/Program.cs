﻿//Grading ID: X7694
//Program 4
//CIS 199-02
//Date: 4/23/2018
//This program will create a reusable class and seperate console application that creates an array of objects
//This program will display the origin zip code, destination zip code, inches, width, height, and weight of a package
//and display the shipping cost in the console


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace PROG4
{
    class Program //First Class, Consisting of Main Argument
    {
        static void Main(string[] args)
        {
            GroundPackage p1 = new GroundPackage(11111, 22222, 100, 20, 30, 10); //Ground Package Data, 5 Objects
            GroundPackage p2 = new GroundPackage(12548, 88888, 150, 40, 60, 25); //Listed p1-5 referring to packages
            GroundPackage p3 = new GroundPackage(46545, 65432, 200, 60, 70, 50);
            GroundPackage p4 = new GroundPackage(12883, 62185, 65, 250, 80, 75);
            GroundPackage p5 = new GroundPackage(87125, 94214, 1, 300, 100, 150);

            GroundPackage[] packages = { p1, p2, p3, p4, p5 }; //Array to store Objects
            DisplayPackages(packages); //Display function to display packages
                      
            display(p1); //display p1
            display(p2); //display p2

        }

        //Pre: Gather values and loop for packages
        //Post: Display Packages, properties and shipping cost via console

        static void DisplayPackages(GroundPackage[] packages) //static void display for ground packages as specified in instructions
        {
            for (int i = 0; i < packages.Length; i++) //For Loop as specified in instructions
            {
                WriteLine("********************************"); //Border
                WriteLine("PACKAGE " + (i + 1)); //Output of Package number 1-5              
                WriteLine("********************************"); //Border
                WriteLine();

                WriteLine(packages[i]); //Output of packages and shipping cost
                WriteLine();
                WriteLine($"{"Shipping Cost",-20}: ${packages[i].CalcCost()}"); //Shipping Cost and Calc Cost
                WriteLine();
                
            }
        }
       
        static void display(GroundPackage package) //static void display for ground packages as specified in the instructions
        {
            WriteLine(package); //
            WriteLine($"{"Shipping Cost",-20}: ${package.CalcCost()}"); //Shipping Cost and Calc Cost
            WriteLine();
        }

    }

    class GroundPackage //Ground Package Class
    {

        public int originZip; //OriginZip
        public int destinationZip; //DestinationZip
        public double length; //Length
        public double width; //Width
        public double height; //Height
        public double weight; //Weight

        //Pre: Constructor to initialize data
        //Post: Return Values using get/set throughout properties and methods
        public GroundPackage(int o, int d, double l, double w, double h, double wt) //Constructor to intialize data
        {

            OriginZip = o; //Data Members
            DestinationZip = d;
            Length = l;
            Height = h;
            Width = w;
            Weight = wt;

        }

        public int OriginZip //OriginZip Int property
        {
            get { return originZip; } 
            set
            {
                if (value >= 10000 && value <= 99999) //Values specified in instructions
                    originZip = value;
                else
                    originZip = 40202; //Otherwise 40202
            }
        }

        public int DestinationZip //DestinationZip Int property
        {
            get { return destinationZip; }
            set
            {
                if (value >= 10000 && value <= 99999) //Values specified in instructions
                    destinationZip = value;
                else
                    destinationZip = 90210; //Otherwise 90210
            }
        }

        public double Length //Length double property
        {
            get { return length; }
            set
            {
                if (value > 0) //Values specified in instructions
                    length = value;
                else
                    length = 1.0; //otherwise 1.0

            }
        }

        public double Width //Width double property
        {
            get { return width; }
            set
            {
                if (value > 0) //Values specified in instructions
                    width = value;
                else
                    width = 1.0; //otherwise 1.0
            }
        }

        public double Height //Height double property
        {
            get { return height; }
            set
            {
                if (value > 0) //values specified in instructions
                    height = value;
                else
                    height = 1.0; //otherwise 1.0

            }
        }

        public double Weight //Weight double property
        {
            get { return weight; }
            set
            {
                if (value > 0) //values specified in instructions
                    weight = value;
                else
                    weight = 1.0; //otherwise 1.0

            }
        }

        public int ZoneDistance //ZoneDistance int property
        {
            get
            {
                int firstOrigin = OriginZip / 10000; //OriginZip divided by 10000 to get first digit
                int firstDestination = OriginZip / 10000; //DestinationZip divided by 10000 to get first digit
                return Math.Abs(firstOrigin - firstDestination); //Used Math Absolute Value to subtract first zip - second zip and return value
            }
        }
        //Precondition: Identifying the properties and applying them within the formula
        //Postcondition: Return Values to main argument and display via console
        public double CalcCost() //CalcCost method
        {
            double shippingCost = .20 * (Length + Width + Height) + .5 * (ZoneDistance + 1) * (Weight); //formula used to calculate shipping cost, supplied in instructions
            return shippingCost; //return shipping cost
        }

        //Precondition: public string, used by main argument for displaying packages and properties
        //Postcondition: Returning packages and properties and displaying via console
        public override string ToString() //String Method
        { 
            return $"{"Origin ZipCode", -20}: {OriginZip}" + //Return properties and methods using Environment.Newline to display new line instead of \n to string
                Environment.NewLine + $"{"Destination ZipCode",-20}: {DestinationZip}" + 
                Environment.NewLine + $"{"Length",-20}: {Length}" + 
                Environment.NewLine + $"{"Width",-20}: {Width}" + 
                Environment.NewLine + $"{"Height",-20}: {Height}" + 
                Environment.NewLine + $"{"Weight",-20}: {Weight}";
        }
    }
}

