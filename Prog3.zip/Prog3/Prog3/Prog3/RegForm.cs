﻿// Program 3
// CIS 199-02
// Due: 4/3/2018
// Grading ID: X7694

// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name.
// Decisions based on UofL Summer/Fall 2018 Priority Registration Schedule

//The logic for this modification to Program 2 will involve using 2 while loops, 1 loop for the upperclassmen and 1 loop for lower class for Registration Times
//I emailed you about using while loops for replacing the if/else statements, have arrays for the letters and times, using range matching through an index
//Used the lower limits so I wouldn't have to rewrite a lot of the code as this was efficient and the material was included within the powerpoints

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 28"; // 1st day of registration
            const string DAY2 = "March 29"; // 2nd day of registration
            const string DAY3 = "March 30"; // 3rd day of registration
            const string DAY4 = "April 2";  // 4th day of registration
            const string DAY5 = "April 3";  // 5th day of registration
            const string DAY6 = "April 4";  // 6th day of registration

            const string TIME1 = "8:30 AM";  // 1st time block
            const string TIME2 = "10:00 AM"; // 2nd time block
            const string TIME3 = "11:30 AM"; // 3rd time block
            const string TIME4 = "2:00 PM";  // 4th time block
            const string TIME5 = "4:00 PM";  // 5th time block

            char[] upperLetters = { 'A', 'E', 'J', 'P', 'T' }; //UpperClass Lower Limits
            string[] upperTimes = { TIME1, TIME2, TIME3, TIME4, TIME5 }; //Upper Class Registration Times

            char[] lowerLetters = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' }; //Lower Class Lower Limits
            string[] lowerTimes = { TIME1, TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4, TIME5 }; //Lower Class Registration Times

            const float SOPHOMORE = 30; // Hours needed to be sophomore
            const float JUNIOR = 60;    // Hours needed to be junior
            const float SENIOR = 90;    // Hours needed to be senior

            string lastNameStr;         // Entered last name
            char lastNameLetterCh;      // First letter of last name, as char
            string dateStr = "Error";   // Holds date of registration
            string timeStr = "Error";   // Holds time of registration
            float creditHours;          // Previously earned credit hours
            bool isUpperClass;          // Upperclass or not?

            bool found; //Implemented Boolean for Range Matching
            int index; //Index for arrays
            
            

            

            lastNameStr = lastNameTxt.Text;
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                if (float.TryParse(creditHoursTxt.Text, out creditHours) && creditHours >= 0)
                {
                    if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                    {
                        isUpperClass = (creditHours >= JUNIOR);

                        // Juniors and Seniors share same schedule but different days
                        if (isUpperClass)
                        {
                            if (creditHours >= SENIOR)
                                dateStr = DAY1;
                            else // Must be juniors
                                dateStr = DAY2;
                            
                            index = upperLetters.Length - 1; //Index for Limits(UpperClass), Starting from End due to using Lower instead of Higher
                            found = false; 

                            while (index >= 0 && !found) //While loop for UpperClass
                            {
                                if (lastNameLetterCh >= upperLetters[index]) //Is LastName greater than or equal to Lower Limit in Index...Found??
                                    found = true;
                                else
                                    --index; //If not found, move down array
                            }
                            if (found)
                                timeStr = upperTimes[index]; //Output for Registration Time using UpperClass Array and Index



                        }
                        // Sophomores and Freshmen
                        else // Must be soph/fresh
                        {
                            if (creditHours >= SOPHOMORE)
                            {
                                // A-L on day one
                                if ((lastNameLetterCh <= 'L'))   // <= L
                                    dateStr = DAY3;
                                else // All other letters on next day
                                    dateStr = DAY4;
                            }
                            else // must be freshman
                            {
                                // A-L on day one
                                if ((lastNameLetterCh <= 'L'))   // <= L
                                    dateStr = DAY5;
                                else // All other letters on next day
                                    dateStr = DAY6;
                            }

                            found = false;
                            index = lowerLetters.Length - 1; //Index for Limits(LowerClass), Starting from End due to using Lower instead of Higher

                            while (index >= 0 && !found) //Using While loop for LowerClass
                            {
                                if (lastNameLetterCh >= lowerLetters[index]) //Is LastName greater than or equal to Lower Limit...Found??
                                    found = true;
                                else
                                    --index; //If not found, move down array
                            }

                            if (found)
                                timeStr = lowerTimes[index]; //Output for Registration Time using LowerClass Array and Index
                        }

                        // Output results
                        dateTimeLbl.Text = dateStr + " at " + timeStr;
                    }
                    else // Not A-Z
                        MessageBox.Show("Make sure last name starts with a letter!");
                }
                else
                    MessageBox.Show("Enter a valid number of credit hours!");
            }
            else // Empty textbox
                MessageBox.Show("Please enter last name!");
        }
    }
}
