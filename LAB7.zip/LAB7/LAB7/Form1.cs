﻿//Grading ID: X7694
//CIS 199-02
//Lab 7
//This program will take an investment and calculate it over time, This method will use future value and present value
//This program will implement value-returning methods


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace LAB7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double futureValue = Double.Parse(FutureValue.Text); //User Input for Future Value
            double r = Double.Parse(AIR.Text); //User Input for Annual Interest Rate
            int n = Int32.Parse(Years.Text); //Number of Years
            double presentValue = calcPresentValue(futureValue, r, n); //Method for calculating present value with three parameters consisting of future value, Interest Rate, and number of years
            string str = presentValue.ToString("C"); //Present value as currency format

            PresentValue.Text = str; //output of present value

        }

        public static double calcPresentValue(double futureValue, double r, double n)
        {

            //Precondition: Future value must be > 0
            //Postcondition: The amount is returned using P = FV / ((1+r)^n) formula to calculate present value
            double a, b, c; //Variables for Formula
            double presentValue; //Present Value
            a = (1 + r); 
            b = n; //Number of Years
            c = Math.Pow(a, b); //Method for takiing annual interest rate to number of years power 

            presentValue = futureValue / c; //calculates present value with formula supplied in lab
            return (presentValue); //method returns Present Value
        }
    }
}
