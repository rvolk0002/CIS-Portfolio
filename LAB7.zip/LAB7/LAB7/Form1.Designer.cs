﻿namespace LAB7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.FutureValue = new System.Windows.Forms.TextBox();
            this.AIR = new System.Windows.Forms.TextBox();
            this.Years = new System.Windows.Forms.TextBox();
            this.PresentValue = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(401, 443);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 51);
            this.button1.TabIndex = 0;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(240, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Future Value: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(240, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(239, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Annual Interest Rate: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(240, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "No. of Year: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(240, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "Present Value: ";
            // 
            // FutureValue
            // 
            this.FutureValue.Location = new System.Drawing.Point(524, 54);
            this.FutureValue.Multiline = true;
            this.FutureValue.Name = "FutureValue";
            this.FutureValue.Size = new System.Drawing.Size(231, 39);
            this.FutureValue.TabIndex = 5;
            // 
            // AIR
            // 
            this.AIR.Location = new System.Drawing.Point(524, 134);
            this.AIR.Multiline = true;
            this.AIR.Name = "AIR";
            this.AIR.Size = new System.Drawing.Size(231, 38);
            this.AIR.TabIndex = 6;
            // 
            // Years
            // 
            this.Years.Location = new System.Drawing.Point(524, 224);
            this.Years.Multiline = true;
            this.Years.Name = "Years";
            this.Years.Size = new System.Drawing.Size(231, 38);
            this.Years.TabIndex = 7;
            // 
            // PresentValue
            // 
            this.PresentValue.Location = new System.Drawing.Point(524, 329);
            this.PresentValue.Multiline = true;
            this.PresentValue.Name = "PresentValue";
            this.PresentValue.Size = new System.Drawing.Size(231, 37);
            this.PresentValue.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 584);
            this.Controls.Add(this.PresentValue);
            this.Controls.Add(this.Years);
            this.Controls.Add(this.AIR);
            this.Controls.Add(this.FutureValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox FutureValue;
        private System.Windows.Forms.TextBox AIR;
        private System.Windows.Forms.TextBox Years;
        private System.Windows.Forms.TextBox PresentValue;
    }
}

