﻿// Grading ID: X7694
// CIS 199-02
// Program 1
// This program will calculate the gallons of paint
// needed to paint the walls in a room and presenting the Total Cost

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Prog1
{
    class Program
    {
        static void Main(string[] args)
        {
            string num1; //User Input
            string num2; //User Input
            string num3; //User Input
            string num4; //User Input
            string num5; //User Input
            string num6; //User Input
            /*Establish Variables*/

            double length; //Length
            double height; //Height
            int doors; //Doors
            int windows; //Windows
            int coats; //Coats of Paint
            int gallonsToBuy; //How many gallons to Buy
            double totalLength; //TotalLength
            double totalLength2; //Total Length of Room
            double gallons; //Gallons of Paint
            double cost; //Cost of Paint per gallon
            double totalCost; //Total Cost of Painting Room

            const double perCan = 375; //Constant sq ft of paint
            const double perDoor = 20; //Constant sq ft per door
            const double perWin = 15; //Constant sq ft per window
            /*Apply Constants*/

            WriteLine("Welcome to the Handy-Dandy Paint Estimator");
            WriteLine();
            Write("Enter the total length of all walls (in feet): ");
            num1 = ReadLine();
            Write("Enter the height of the walls (in feet): ");
            num2 = ReadLine();
            Write("Enter the number of doors (non-neg int): ");
            num3 = ReadLine();
            Write("Enter the number of windows (non-neg int): ");
            num4 = ReadLine();
            Write("Enter the number of coats of paint (non-neg int): ");
            num5 = ReadLine();
            Write("Enter the cost per gallon of paint (in $): ");
            num6 = ReadLine();
            WriteLine();
            /*User Input*/


            length = double.Parse(num1);
            height = double.Parse(num2);
            doors = Int32.Parse(num3);
            windows = Int32.Parse(num4);
            coats = Int32.Parse(num5);
            cost = double.Parse(num6);
            /*Parse Strings*/

            totalLength = ((length * height) - (doors * perDoor) - (windows * perWin)); //Total Length Calculation
            totalLength2 = (totalLength * coats); //Total Length of Room Calculation
            gallons = (totalLength2 / perCan); //Total Gallons Used Calculation
            gallonsToBuy = (int)Math.Ceiling(gallons); //How many gallons to buy Calculation
            totalCost = (cost * gallonsToBuy); //Total Cost of Job
            /*Calculations*/

            Console.WriteLine($"You need a minimum of {gallons:f1} gallons of paint."); //Output of Gallons
            Console.WriteLine($"You'll need to buy {gallonsToBuy} gallons, though,"); //Output of Gallons to Buy
            Console.WriteLine($"at a cost of {totalCost:C}."); //Output of Total Cost
            /*Output*/
        }
    }
}
