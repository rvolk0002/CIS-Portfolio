﻿namespace PROG_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Register = new System.Windows.Forms.Button();
            this.Last_Name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Output = new System.Windows.Forms.TextBox();
            this.Credit_Hours = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Register
            // 
            this.Register.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Register.Location = new System.Drawing.Point(384, 450);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(292, 79);
            this.Register.TabIndex = 0;
            this.Register.Text = "REGISTER";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // Last_Name
            // 
            this.Last_Name.Location = new System.Drawing.Point(582, 102);
            this.Last_Name.Multiline = true;
            this.Last_Name.Name = "Last_Name";
            this.Last_Name.Size = new System.Drawing.Size(195, 39);
            this.Last_Name.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 105);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(452, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please enter first letter of Last Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(47, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 29);
            this.label2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(276, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(546, 40);
            this.label3.TabIndex = 8;
            this.label3.Text = "SPRING 2018 REGISTRATION";
            // 
            // Output
            // 
            this.Output.Location = new System.Drawing.Point(235, 562);
            this.Output.Multiline = true;
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(602, 121);
            this.Output.TabIndex = 9;
            // 
            // Credit_Hours
            // 
            this.Credit_Hours.Location = new System.Drawing.Point(582, 184);
            this.Credit_Hours.Multiline = true;
            this.Credit_Hours.Name = "Credit_Hours";
            this.Credit_Hours.Size = new System.Drawing.Size(195, 48);
            this.Credit_Hours.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(52, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(331, 29);
            this.label4.TabIndex = 11;
            this.label4.Text = "Please Enter Credit Hours: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(369, 263);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(342, 145);
            this.label5.TabIndex = 12;
            this.label5.Text = "Credit Hour Grade Level Chart:\r\nSenior - 90+\r\nJunior - 60-90\r\nSophmore - 30-60\r\nF" +
    "reshman - Under 30\r\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 695);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Credit_Hours);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Last_Name);
            this.Controls.Add(this.Register);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.TextBox Last_Name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Output;
        private System.Windows.Forms.TextBox Credit_Hours;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

