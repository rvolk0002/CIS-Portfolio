﻿//Grading ID: X7694
//CIS 199-02
//Program 2
//March 6, 2018
//This program will display the students registration date based off of 
//last name and grade level

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Console;

namespace PROG_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, EventArgs e)
        {
            double creditHours; //Number of Credit Hours
            char lastNameLetter; //First Letter of Last Name
            string lastNameAsString; //User Input
            string dateAsString = ""; //Date of Registration
            string timeAsString = ""; //Time of Registration
            bool Upper_Class; //Boolean for Upperclassman
            bool Lower_Class; //Boolean for Lowerclassman
            
            

            lastNameAsString = Last_Name.Text; //User Input
            creditHours = Convert.ToDouble(Credit_Hours.Text); //converting user input to double format

            if (lastNameAsString.Length == 1) //String must be one character or error message displays via message box
            {
                lastNameLetter = lastNameAsString[0]; //Validate only first character of last name
                lastNameLetter = char.ToUpper(lastNameLetter); //Uppercase

                if (char.IsLetter(lastNameLetter)) //Check to see if its a letter
                {
                    Upper_Class = (creditHours >= 90 || creditHours >= 60); //Filter between Seniors and Juniors

                    if (Upper_Class)
                    {
                        if (creditHours >= 90) //Senior
                            dateAsString = "March 28";
                        else                   //Junior
                            dateAsString = "March 29";

                        if (lastNameLetter <= 'D') //A-D
                            timeAsString = "8:30 AM";
                        else if (lastNameLetter <= 'I') //E-I
                            timeAsString = "10:00 AM";
                        else if (lastNameLetter <= 'O') //J-O
                            timeAsString = "11:30 AM";
                        else if (lastNameLetter <= 'S') //P-S
                            timeAsString = "2:00 PM";
                        else
                            timeAsString = "4:00 PM"; //T-Z
                    }
                    else
                    {
                        Lower_Class = (creditHours >= 30 || creditHours < 30); //Filter between Freshman and Sophmores


                        if (Lower_Class) 
                        {
                            if (creditHours >= 30) //Sophmores
                            {
                                if ((lastNameLetter >= 'A') && (lastNameLetter <= 'L')) //Sophmores with first letter of last name from A - L??

                                    dateAsString = "March 30"; //Sophmores last name A - L
                                else
                                    dateAsString = "April 2"; //Sophmores last name M - Z
                            }

                            if (creditHours < 30) //Freshman
                            {
                                if((lastNameLetter >= 'M') && (lastNameLetter <= 'Z')) //Freshman with first letter of last name from M - Z??

                                    dateAsString = "April 4"; //Freshman last name M - Z
                                else
                                    dateAsString = "April 3"; //Freshman last name A - L
                            }

                                if (lastNameLetter <= 'B') //A - B
                                    timeAsString = "8:30 AM";
                                else if (lastNameLetter <= 'D') //C - D
                                    timeAsString = "10:00 AM";
                                else if (lastNameLetter <= 'F') //E - F
                                    timeAsString = "11:30 AM";
                                else if (lastNameLetter <= 'I') //G - I
                                    timeAsString = "2:00 PM";
                                else if (lastNameLetter <= 'L') //J - L
                                    timeAsString = "4:00 PM";
                                else if (lastNameLetter <= 'O') //M - O
                                    timeAsString = "8:30 AM";
                                else if (lastNameLetter <= 'Q') //P - Q
                                    timeAsString = "10:00 AM";
                                else if (lastNameLetter <= 'S') //R - S
                                    timeAsString = "11:30 AM";
                                else if (lastNameLetter <= 'V') //T - V
                                    timeAsString = "2:00 PM";
                                else
                                    timeAsString = "4:00 PM"; //W - Z
                            
                        }
                        
                        
                    }
                    Output.Text = dateAsString + " at " + timeAsString; //Output of Date and Time of Registration for Student

                }
                else
                    MessageBox.Show("Please enter First Letter of Last Name"); //Error message if criteria was not met 

            }
            else
                MessageBox.Show("Please enter First Letter of Last Name"); //Error message if criteria was not met
                



        }
    }
}
